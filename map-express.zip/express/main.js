const express = require('express')
var cors = require('cors')
const app = express()
const port = 3001

app.use(cors())


app.get('/offices', (req, res) => {

    res.sendFile('offices.json', {

        root: './'

    });
    // console.log("offices")
})

app.get('/zipcodes', (req, res) => {

    res.sendFile('ZipCodes.json', {

        root: './'

    });
    // console.log("zip codes")
})

app.get('/agents', (req, res) => {

    res.sendFile('agent.json', {

        root: './'

    });
    // console.log("agents")
})

app.get("/house/single", (req, res) => {

    let house, url, splitAddress, value;

    house = require('./house.json');

    url = req.url

    splitAddress = url.split("=")

    value = splitAddress[1]

    for (let i = 0; i < house.length; i++) {

        let houseId = house[i].address.replace(/\s/g, '');

        if (houseId === value) {    

            console.log("yes")
            res.json(house[i])

            break;

        }

    }

})

app.get('/house', (req, res) => {

    let input, i, index, house, array, compare, neIndex, ne, url;

    house = require('./house.json');

    url = req.url;

    array = [];

    if (url.includes("input=")) {

        let newUrl = url.replace(/%20/g, " ");

        index = newUrl.indexOf("=")

        input = newUrl.substring(index + 1)

        for (i = 0; i < house.length; i++) {

            regex = new RegExp(input, "gi")
            compare = regex.exec(house[i].address)

            if (compare) {

                // console.log("input: " + input + "\ncompare: " + compare)

                array.push(house[i])

            }

        }


        res.json(array)


    } else {

        let query = url.substr(7);
        let par = {}
        query.split("&").forEach(function (part) {

            let key = part.split("=")[0]
            let value = part.split("=")[1]
            value = parseFloat(value)

            par["" + key + ""] = value

        })

        // console.log(par)

        for (i = 0; i < house.length; i++) {

            if (array.length === 500) { break }

            if ((house[i].cords[0] > par.swlng && house[i].cords[0] < par.nelng) && (house[i].cords[1] > par.swlat && house[i].cords[1] < par.nelat)) {

                if (par.beds && par.baths) {

                    if (house[i].total_bedrooms >= par.beds && house[i].total_bathrooms >= par.baths) {

                        array.push(house[i])

                        continue;

                    }

                } else if (par.beds) {

                    if (house[i].total_bedrooms >= par.beds) {

                        array.push(house[i])

                        continue

                    }

                } else if (par.baths) {

                    if (house[i].total_bathrooms >= par.baths) {

                        array.push(house[i])

                        continue

                    }

                } else {

                    array.push(house[i])

                }

            }



        }


        res.json(array)
    }


})

app.get('/house/browse', (req, res) => {

    let input, i, index, house, array, compare, neIndex, ne;
    array = [];

    house = require('./house.json');

    for (i = 0; i < house.length; i++) {

        if (array.length === 500) {
            break;
        }

        array.push(house[i])

    }

    res.json(array)

    // console.log("houseBrowse")

})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))